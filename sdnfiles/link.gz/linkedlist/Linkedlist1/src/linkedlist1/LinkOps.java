/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linkedlist1;

/**
 *
 * @author root
 */
public class LinkOps {
    
    public Node root;
    public Node linkup;
    public Node lastnode;
    public void create(int data)
    {
        Node n = new Node(data);
        if(root == null)
        {
            root = n;
            linkup = n;
            System.out.println("root: "+root);
        }
        else
        {
            Node current = linkup;
            current.next = n;
            linkup = n;
        }
        lastnode = n;
    }
    
    public void display()
    {
        Node d = root;
        while(d != null)
        {
            System.out.print(" "+d.data);
         //   System.out.println(d);
            d = d.next;
            if(d != null)
                System.out.print(" ->");
        }
                System.out.println("");
    }

    public void removefirst()
    {
        root = root.next;
    }
    public void removelast()
    {
        Node c = root;
        Node cj;
        while(c != null)
        {
            cj = c;
            c = c.next;
            Node ct = c.next;
            if(ct == null)
            {
                c = cj;
                c.next = null;
                break;
            }
        }
    }
}
