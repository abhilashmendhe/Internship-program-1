/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package linkedlist1;

import java.util.LinkedList;

/**
 *
 * @author root
 */
public class Linkedlist1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        LinkOps list = new LinkOps();
        list.create(1);
        list.create(2);
        list.create(3);
        list.create(4);
        list.create(5);
        list.display();
        
        list.removefirst();
        list.display();
        list.removelast();
        list.display();
        
    }
    
}
